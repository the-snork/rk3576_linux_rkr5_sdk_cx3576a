from blueman.bluez.Base import Base


class Battery(Base):
    _interface_name = "org.bluez.Battery1"
